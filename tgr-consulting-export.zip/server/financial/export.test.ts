import { describe, expect, it } from "vitest";
import JSZip from "jszip";
import { buildBoardroomPdf, buildBoardroomPptx } from "./export";

const snapshot = {
  status: "valid" as const,
  horizonMonths: 12,
  missingInputKeys: [],
  formulaSetVersion: "1.0.0",
  engineVersion: "igr-engine-1.0.0",
  projections: [],
  kpis: {
    grossSales: "100.00000000",
    recognizedRevenue: "80.00000000",
    totalOperatingCashFlow: "50.00000000",
    npv: "42.00000000",
    irrAnnual: "0.12000000",
    paybackMonths: "8.00000000",
  },
  memory: [
    { kpiKey: "npv", label: "Valor presente líquido", value: "42.00000000", formulaId: "npv", formulaVersion: "1.0.0", expression: "Σ", dependencies: ["operating-cash-flow"], explanation: "Valor presente dos fluxos." },
  ],
  snapshotHash: "a".repeat(64),
};

describe("geradores de artefato Boardroom", () => {
  it("gera PDF com conteúdo a partir de snapshot", async () => {
    const bytes = await buildBoardroomPdf(snapshot);
    expect(bytes.byteLength).toBeGreaterThan(500);
    expect(String.fromCharCode(...bytes.slice(0, 4))).toBe("%PDF");
  });

  it("gera PPTX com conteúdo a partir de snapshot", async () => {
    const buffer = await buildBoardroomPptx(snapshot);
    expect(buffer.byteLength).toBeGreaterThan(500);
    expect(buffer.slice(0, 2).toString()).toBe("PK");
    const archive = await JSZip.loadAsync(buffer);
    expect(archive.file("[Content_Types].xml")).toBeTruthy();
    expect(archive.file("ppt/presentation.xml")).toBeTruthy();
    expect(archive.file("ppt/slides/slide1.xml")).toBeTruthy();
  });
});
